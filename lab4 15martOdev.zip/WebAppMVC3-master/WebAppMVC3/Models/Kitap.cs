﻿namespace WebAppMVC3.Models
{
    public class Kitap
    {
        public int Id { get; set; }
        public string Ad { get; set; }
        public string Yazar { get; set; }
        public string Kategori { get; set; }
        public string YayinEvi { get; set; }
    }
}
