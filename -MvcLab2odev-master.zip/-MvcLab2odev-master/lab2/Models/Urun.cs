﻿namespace lab2.Models
{
    public class Urun
    {
        public int Id { get; set; }
        public string Isım { get; set; }
        public string Aciklama { get; set; }
        public string Kategori { get; set; }
        public int Fiyat { get; set; }
    }
}
